Created by Robert Vinluan. 2012.

Controls:
Move around to build up static.
Press SPACE to fire static balls at zombies.
When you've cleared the room, go all the way to the right and press UP to advance.
Don't die.

